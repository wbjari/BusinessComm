@extends('layouts.master')
@section('title', 'Home')
@section('content')
@include('includes.header')
<div class="container text-center">
  <h1>404 - Pagina niet gevonden</h1>
</div>
@include('includes.footer')
@endsection
