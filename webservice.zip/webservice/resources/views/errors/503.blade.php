@extends('layouts.master')
@section('title', 'Home')
@section('content')
@include('includes.header')
<div class="container text-center">
  <h1>503 - We zijn op dit moment bezig met het onderhouden van de website</h1>
</div>
@include('includes.footer')
@endsection
