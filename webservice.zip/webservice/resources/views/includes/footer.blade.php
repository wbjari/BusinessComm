<div class="container">
  <hr>
  <footer>
    <p>&copy; <?= date('Y'); ?> BusinessComm, Inc.</p>
  </footer>
</div>
