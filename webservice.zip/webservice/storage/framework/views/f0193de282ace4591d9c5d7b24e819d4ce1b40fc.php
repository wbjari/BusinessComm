<?php $__env->startSection('title', 'Profile'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="profile-header">
  <div class="container">
    <div <?php if($user->id == \Auth::id()): ?> class="profileimg-container" data-toggle="modal" data-target="#changeProfilePictureModal" <?php endif; ?>>
      <?php if($user->profilepicture): ?>
      <img src="<?php echo e(url($user->profilepicture)); ?>" alt="<?php echo e($user->firstname); ?>&nbsp;<?php echo e($user->lastname); ?>">
      <?php else: ?>
      <img src="<?php echo e(url('assets/img/avatar.png')); ?>" id="profile" alt="<?php echo e($user->firstname); ?>&nbsp;<?php echo e($user->lastname); ?>">
      <?php endif; ?>
      <?php if($user->id == \Auth::id()): ?>
      <i class="material-icons profile-picture-edit">camera_alt</i>
      <?php endif; ?>
    </div>
    <h1><span <?php if($user->id == \Auth::id()): ?> data-profile="firstname" <?php endif; ?>><?php echo e($user->firstname); ?></span>&nbsp;<span <?php if($user->id == \Auth::id()): ?> data-profile="lastname" <?php endif; ?>><?php echo e($user->lastname); ?></span></h1>
    <h5>
      <?php if($user->location): ?>
      <span <?php if($user->id == \Auth::id()): ?> data-profile="location" <?php endif; ?>><?php echo e($user->location); ?></span>,
      <?php elseif(!$user->location && $user->id == \Auth::id()): ?>
      <span data-profile="location" class="text-muted">Vul hier uw woonplaats in</span>,
      <?php endif; ?>
      <?php if($user->province): ?>
      <span <?php if($user->id == \Auth::id()): ?> data-profile="province" <?php endif; ?>><?php echo e($user->province); ?></span>,
      <?php elseif(!$user->province && $user->id == \Auth::id()): ?>
      <span data-profile="province" class="text-muted">Vul hier uw provincie</span>,
      <?php endif; ?>
      <?php if($user->country): ?>
      <span <?php if($user->id == \Auth::id()): ?> data-profile="country" <?php endif; ?>><?php echo e($user->country); ?></span>
      <?php elseif(!$user->country && $user->id == \Auth::id()): ?>
      <span data-profile="country" class="text-muted">Vul hier uw land in</span>
      <?php endif; ?>
    </h5>
  </div>
</div>
<div class="container">
  <div class="notifications">
    <?php if(session('notification')): ?>
    <div class="col-md-12">
      <div class="alert alert-info">
        <div class="container-fluid">
          <div class="alert-icon">
            <i class="material-icons">info_outline</i>
          </div>
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true"><i class="material-icons">clear</i></span>
          </button>
          <b>Info:</b> <span class="message"><?php echo e(session('notification')); ?></span>
        </div>
      </div>
    </div>
    <?php endif; ?>
  </div>
  <div class="timeline col-xs-12 col-md-6 col-md-offset-3">
    <div class="card">
      <div class="col-md-12">
        <h2>Over mij</h2>
        <?php if($user->biography): ?>
        <p <?php if($user->id == \Auth::id()): ?> data-profile="biography" <?php endif; ?>><?php echo e($user->biography); ?></p>
        <?php elseif(!$user->biography && $user->id == \Auth::id()): ?>
        <p data-profile="biography" class="text-muted">Vertel iets over jezelf.</p>
        <?php endif; ?>
      </div>
    </div>
    <div class="card">
      <div class="col-md-12">
        <h2>Vaardigheden</h2>
        <div <?php if($user->id == \Auth::id()): ?> data-card="skills" <?php endif; ?>>
          <?php if(count($user_skills) > 0): ?>
          <?php $i = 1 ?>
          <?php foreach($user_skills as $skill): ?>
          <span class="label label-primary" <?php if($user->id == \Auth::id()): ?> data-profile="skill-<?php echo e($i); ?>" data-id="<?php echo e($skill['id']); ?>" data-profile-array="skill" data-color="#000"<?php endif; ?>><?php echo e($skill['name']); ?> <?php if($user->id == \Auth::id()): ?><i class="material-icons">delete_forever</i><?php endif; ?></span>
          <?php $i++ ?>
          <?php endforeach; ?>
          <?php endif; ?>
        </div>
      </div>
      <?php if($user->id == \Auth::id()): ?>
      <div class="col-md-12 text-right">
        <button class="btn btn-primary btn-xs" data-toggle="modal" data-target="#add_skill">
          Vaardigheid toevoegen
          <div class="ripple-container"></div>
        </button>
      </div>
      <?php endif; ?>
    </div>
    <div class="card">
      <div class="col-md-12">
        <h2>Aanvullende informatie</h2>
        <table class="table">
          <tbody>
            <tr>
              <th>Adres</th>
            </tr>
            <?php if($user->address): ?>
            <tr>
              <td <?php if($user->id == \Auth::id()): ?> data-profile="address" <?php endif; ?>><?php echo e($user->address); ?></td>
            </tr>
            <?php elseif(!$user->address && $user->id == \Auth::id()): ?>
            <tr>
              <td data-profile="address" class="text-muted">Vul hier jouw adres in.</td>
            </tr>
            <?php endif; ?>
            <tr>
              <th>Postcode</th>
            </tr>
            <?php if($user->zipcode): ?>
            <tr>
              <td <?php if($user->id == \Auth::id()): ?> data-profile="zipcode" <?php endif; ?>><?php echo e($user->zipcode); ?></td>
            </tr>
            <?php elseif(!$user->address && $user->id == \Auth::id()): ?>
            <tr>
              <td data-profile="zipcode" class="text-muted">Vul hier jouw postcode in.</td>
            </tr>
            <?php endif; ?>
            <tr>
              <th>Plaats</th>
            </tr>
            <?php if($user->location): ?>
            <tr>
              <td <?php if($user->id == \Auth::id()): ?> data-profile="location" <?php endif; ?>><?php echo e($user->location); ?></td>
            </tr>
            <?php elseif(!$user->address && $user->id == \Auth::id()): ?>
            <tr>
              <td data-profile="location" class="text-muted">Vul hier jouw woonplaats in.</td>
            </tr>
            <?php endif; ?>
            <tr>
              <th>Provincie</th>
            </tr>
            <?php if($user->province): ?>
            <tr>
              <td <?php if($user->id == \Auth::id()): ?> data-profile="province" <?php endif; ?>><?php echo e($user->province); ?></td>
            </tr>
            <?php elseif(!$user->address && $user->id == \Auth::id()): ?>
            <tr>
              <td data-profile="province" class="text-muted">Vul hier jouw provincie in.</td>
            </tr>
            <?php endif; ?>
            <tr>
              <th>Land</th>
            </tr>
            <?php if($user->country): ?>
            <tr>
              <td <?php if($user->id == \Auth::id()): ?> data-profile="country" <?php endif; ?>><?php echo e($user->country); ?></td>
            </tr>
            <?php elseif(!$user->address && $user->id == \Auth::id()): ?>
            <tr>
              <td data-profile="country" class="text-muted">Vul hier jouw land in.</td>
            </tr>
            <?php endif; ?>
            <tr>
              <th>E-mailadres</th>
            </tr>
            <tr>
              <td><?php echo e($user->email); ?></td>
            </tr>
            <tr>
              <th>Telefoonnummer</th>
            </tr>
            <?php if($user->telephone): ?>
            <tr>
              <td <?php if($user->id == \Auth::id()): ?> data-profile="telephone" <?php endif; ?>><?php echo e($user->telephone); ?></td>
            </tr>
            <?php elseif(!$user->address && $user->id == \Auth::id()): ?>
            <tr>
              <td data-profile="telephone" class="text-muted">Vul hier jouw telefoonnummer in.</td>
            </tr>
            <?php endif; ?>
            <tr>
              <th>Mobiel</th>
            </tr>
            <?php if($user->mobile): ?>
            <tr>
              <td <?php if($user->id == \Auth::id()): ?> data-profile="mobile" <?php endif; ?>><?php echo e($user->mobile); ?></td>
            </tr>
            <?php elseif(!$user->address && $user->id == \Auth::id()): ?>
            <tr>
              <td data-profile="mobile" class="text-muted">Vul hier jouw mobiele nummer in.</td>
            </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?php if($user->id == \Auth::id()): ?>
<!-- VAARDIGHEID TOEVOEGEN -->
<div class="modal fade" id="add_skill" tabindex="-1" role="dialog" aria-labelledby="add_skill" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true"><i class="material-icons">clear</i></button>
        <h4 class="modal-title">Vaardigheid toevoegen</h4>
      </div>
      <div class="modal-body">
        <form data-name="skills">
          <input type="text" class="form-control" name="skill" id="skillSearch" placeholder="Vaardigheid" required>
        </form>
        <div id="skillResult"></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Annuleren</button>
        <button type="button" class="btn btn-info" data-dismiss="modal" data-profile-add="skills">Toevoegen</button>
      </div>
    </div>
  </div>
</div>
<div class="modal fade" id="changeProfilePictureModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="myModalLabel">Foto aanpassen</h4>
      </div>
      <form id="changeLogoForm" method="POST" enctype="multipart/form-data" action="/change-profile-picture">
        <?php echo csrf_field(); ?>

        <div class="modal-body">
          <div class="col-sm-6">
            <label class="control-label">Afbeelding</label>
            <input type="file" id="changePic" name="changePic" accept="image/jpeg, image/png">
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Sluiten</button>
          <button type="submit" class="btn btn-info">Opslaan</button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php endif; ?>
<div class="modal fade" id="reportUser" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="myModalLabel"><?php echo e($user->firstname.' '.$user->lastname); ?> rapporteren</h4>
      </div>
      <form id="reportUserForm" method="POST" enctype="multipart/form-data" action="/user/report">
        <?php echo csrf_field(); ?>

        <input type="hidden" name="user" value="<?php echo e($user->id); ?>">
        <div class="modal-body">
          <input type="text" name="reason" placeholder="Reden" class="form-control" required>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Annuleren</button>
          <button type="submit" class="btn btn-danger">Rapporteren</button>
        </div>
      </form>
    </div>
  </div>
</div>
<button class="btn-profile-save btn btn-primary btn-raised btn-fab btn-round">
  <i class="material-icons">save</i>
</button>
<script>
  var currPage = "user/<?php echo e($user->id); ?>/edit";
</script>
<?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>