<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="jumbotron jumbotron-homepage">
  <div class="text-white text-center">
    <div class="container">
      <img src="assets/img/logo-white-shadow.png" alt="BusinessComm" />
      <h2>BusinessComm, hét social media platform voor uw bedrijf!</h2>
    </div>
  </div>
</div>
<div class="container">
  <div class="notifications">
    <?php if(session('notification')): ?>
    <div class="col-md-12">
      <div class="alert alert-info">
        <div class="container-fluid">
          <div class="alert-icon">
            <i class="material-icons">info_outline</i>
          </div>
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true"><i class="material-icons">clear</i></span>
          </button>
          <b>Info:</b> <span class="message"><?php echo e(session('notification')); ?></span>
        </div>
      </div>
    </div>
    <?php endif; ?>
  </div>
  <div class="row">
    <div class="col-md-offset-1 col-md-4 col-xs-offset-1 col-xs-10 text-center">
      <i class="material-icons">person</i>
      <h3>Creëer je eigen profiel</h3>
      <p>Schrijf je in, vind bedrijven in de buurt en vergemakkelijk het contact tussen de personen binnen het bedrijf!</p>
      <a href="<?php echo e(url('/register')); ?>">
      <button class="btn btn-raised btn-info btn-sm">Eigen profiel aanmaken</button>
      </a>
    </div>
    <div class="col-md-offset-2 col-md-4 col-xs-offset-1 col-xs-10 text-center">
      <i class="material-icons">business</i>
      <h3>Schrijf jouw bedrijf in!</h3>
      <p>Wacht niet langer en schrijf jouw bedrijf nu in om van de functionaliteiten te profiteren!</p>
      <p><small><strong>*Profiel vereist</strong></small></p>
      <a href="<?php echo e(url('/create-company')); ?>">
      <button class="btn btn-raised btn-info btn-sm">Bedrijf inschrijven</button>
      </a>
    </div>
  </div>
</div>
<?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>