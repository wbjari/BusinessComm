<!DOCTYPE html>
<html>
  <head>
    <title><?php echo $__env->yieldContent('title'); ?> | BusinessComm</title>
    <meta name="_token" content="<?php echo e(csrf_token()); ?>" />
    <meta name="url" content="<?php echo e(url('/')); ?>" />
    <?php if(isset($company)): ?>
    <meta name="company" content="<?php echo e($company->id); ?>">
    <?php endif; ?>
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons" />
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" />
    <link href="<?php echo e(url('assets/css/bootstrap.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(url('/assets/css/material-kit.css')); ?>" rel="stylesheet" />
    <link rel="stylesheet" href="<?php echo e(url('assets/css/core.css')); ?>" media="screen" charset="utf-8" />
  </head>
  <body>
    <?php echo $__env->yieldContent('content'); ?>
    <script src="<?php echo e(url('assets/js/jquery.min.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(url('assets/js/bootstrap.min.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(url('assets/js/material.min.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(url('assets/js/material-kit.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(url('assets/js/jquery.ui.widget.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(url('assets/js/jquery.fileupload.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(url('assets/js/core.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(url('assets/js/ajax.js')); ?>" type="text/javascript"></script>
  </body>
</html>
