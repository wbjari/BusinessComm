<?php $__env->startSection('title', 'Inloggen'); ?>
<?php $__env->startSection('content'); ?>
<div class="page-lr" id="login">
  <img src="assets/img/logo-white.png" alt="BusinessComm" />
  <h1><?php echo $__env->yieldContent('title'); ?></h1>
  <div class="around">
    <div class="block-lr">
      <form role="form" method="POST" action="<?php echo e(url('/login')); ?>">
        <?php echo csrf_field(); ?>

        <div class="col-sm-12">
          <div class="form-group info label-floating <?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
            <label class="control-label">E-mailadres</label>
            <input type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required>
            <?php if($errors->has('email')): ?>
            <span class="help-block">
            <strong><?php echo e($errors->first('email')); ?></strong>
            </span>
            <?php endif; ?>
          </div>
        </div>
        <div class="col-sm-6">
          <div class="form-group info label-floating <?php echo e($errors->has('password') ? ' has-error' : ''); ?>" required>
            <label class="control-label">Wachtwoord</label>
            <input type="password" class="form-control" name="password">
            <?php if($errors->has('password')): ?>
            <span class="help-block">
            <strong><?php echo e($errors->first('password')); ?></strong>
            </span>
            <?php endif; ?>
          </div>
        </div>
        <div class="col-sm-6">
          <div class="form-group info">
            <div class="checkbox">
              <label>
              <input type="checkbox" name="remember"> Onthouden
              </label>
            </div>
          </div>
        </div>
        <!-- <a class="btn btn-danger col-sm-12" href="<?php echo e(url('/password/reset')); ?>">Wachtwoord vergeten?</a> -->
        <button type="submit" class="btn btn-success btn-raised btn-fab btn-round form-submit btn-lr">
        <i class="material-icons">forward</i>
        </button>
        <div class="clearfix"></div>
      </form>
      <div class="msg-below-lr">
        <a href="<?php echo e(url('/register')); ?>" class="btn btn-raised btn-info btn-xs">Ik heb nog geen account</a>
      </div>
      <div class="clearfix"> </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>