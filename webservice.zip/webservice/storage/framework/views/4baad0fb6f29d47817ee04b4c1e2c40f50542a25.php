<?php $__env->startSection('title', 'Bedrijf'); ?>

<?php $__env->startSection('content'); ?>

  <?php echo $__env->make('includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<div class="profile-header">
		<div class="container company-profile">
      <div class="img-container" data-toggle="modal" data-target="#changeLogoModal">
        <?php if($company->logo): ?>
          <img src="<?php echo e(url($company['logo'])); ?>" alt="<?php echo e($company['name']); ?>">
        <?php else: ?>
          <img src="<?php echo e(url('assets/img/company.png')); ?>" alt="<?php echo e($company['name']); ?>">
        <?php endif; ?>
        <i class="material-icons profile-picture-edit">camera_alt</i>
      </div>

			<h1 data-profile="name"><?php echo e($company['name']); ?></h1>
      <?php if($company['slogan']): ?>
        <h2 data-profile="slogan"><?php echo e($company['slogan']); ?></h2>
      <?php else: ?>
        <h2 data-profile="slogan" class="text-muted">Vul hier jouw bedrijfs slogan in.</h2>
      <?php endif; ?>
			<h5>
        <?php if($company['location']): ?>
          <span data-profile="location"><?php echo e($company['location']); ?></span>,
        <?php else: ?>
          <span data-profile="location" class="text-muted">Vul hier de locatie in.</span>,
        <?php endif; ?>
        <?php if($company['province']): ?>
          <span data-profile="province"><?php echo e($company['province']); ?></span>,
        <?php else: ?>
          <span data-profile="province" class="text-muted">Vul hier de provincie in.</span>,
        <?php endif; ?>
        <?php if($company['country']): ?>
          <span data-profile="country"><?php echo e($company['country']); ?></span>
        <?php else: ?>
          <span data-profile="country" class="text-muted">Vul hier het land in.</span>
        <?php endif; ?>
      </h5>
      <div class="clearfix"> </div>
		</div>
	</div>

	<div class="container">

    <?php if($role == 2 || $role == 3): ?>
      <?php if($requests->count() != 0): ?>
      <div class="card requests">
        <div class="col-md-12">
          <h2>Verzoeken</h2>
          <ul>
            <?php foreach($requests as $request): ?>

              <li data-id="<?php echo e($request['user_id']); ?>">
                <a href="<?php echo e(url('/user/' . $request['user_id'])); ?>"><?php echo e($request['firstname']); ?> <?php echo e($request['lastname']); ?></a>
                <br />
                <button type="button" class="btn btn-success btn-sm btn-raised" data-type="accept" name="button">Accepteren</button>
                <button type="button" class="btn btn-danger btn-sm btn-raised" data-type="accept" name="button">Weigeren</button>
              </li>

            <?php endforeach; ?>
          </ul>
        </div>
      </div>
      <?php endif; ?>
    <?php endif; ?>

  <div class="timeline col-xs-12 col-md-6 col-md-offset-3">
    <div class="card">
      <div class="col-md-12">
        <h2>Leden</h2>
        <?php if(count($members) < 1): ?>
          <h4 class="no-result">Geen leden gevonden...</h4>
        <?php else: ?>
        <table class="table">
            <thead>
              <tr>
                <th>Naam</th>
                <th>Email</th>
                <th>Rechten</th>
                <th class="text-right">Acties</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach($members as $member): ?>
              <tr>
                  <td><a href="<?php echo e(url('/user/' . $member->id)); ?>"><?php echo e($member->firstname.' '.$member->lastname); ?></a></td>
                  <td><?php echo e($member->email); ?></td>

                  <td>
                  <?php if($member->role === 'Beheerder'): ?>
                    <?php echo e($member->role); ?>

                  <?php else: ?>
                  <form action="<?php echo e(url('/company/'.$company->id.'/users/edit')); ?>" enctype="multipart/form-data" method="POST">
                    <?php echo csrf_field(); ?>

                    <input type="hidden" name="id" value="<?php echo e($member->id); ?>">
                    <select name="userRole" id="userRole">
                      <option value="<?php echo e($member->role); ?>"><?php echo e($member->role); ?></option>
                      <?php if($member->role !== 'Mede-beheerder'): ?>
                        <option value="Mede-beheerder">Mede-beheerder</option>
                      <?php endif; ?>
                      <?php if($member->role !== 'Lid'): ?>
                        <option value="Lid">Lid</option>
                      <?php endif; ?>
                      <option value="Verwijderen">Verwijderen</option>
                    </select>
                    <td class="td-actions text-right">
                      <button type="submit" class="btn btn-info btn-simple btn-xs"><i class="material-icons">save</i></button>
                    </td>
                  <?php endif; ?>
                  </td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </form>
      <?php endif; ?>
      </div>
    </div>

    <div class="card">
        <div class="col-md-12">
          <h2>Aanvullende informatie</h2>

          <table class="table">
            <tbody>
              <?php if($company->email): ?>
                <tr><th>Adres</th></tr>
                <tr><td><?php echo e($company->email); ?></td></tr>
              <?php endif; ?>

              <tr><th>Telefoon</th></tr>
              <?php if($company->telephone): ?>
                <tr><td data-profile="telephone"><?php echo e($company->telephone); ?></td></tr>
              <?php else: ?>
                <tr><td data-profile="telephone" class="text-muted">Vul hier uw telefoonnummer in.</td></tr>
              <?php endif; ?>

              <tr><th>Adres</th></tr>
              <?php if($company->address): ?>
                <tr><td data-profile="address"><?php echo e($company->address); ?></td></tr>
              <?php else: ?>
                <tr><td data-profile="address" class="text-muted">Vul hier uw adres in.</td></tr>
              <?php endif; ?>

              <tr><th>Postcode</th></tr>
              <?php if($company->zipcode): ?>
                <tr><td data-profile="zipcode"><?php echo e($company->zipcode); ?></td></tr>
              <?php else: ?>
                <tr><td data-profile="zipcode" class="text-muted">Vul hier uw postcode in.</td></tr>
              <?php endif; ?>

              <tr><th>Plaats</th></tr>
              <?php if($company->location): ?>
                <tr><td data-profile="location"><?php echo e($company->location); ?></td></tr>
              <?php else: ?>
                <tr><td data-profile="location" class="text-muted">Vul hier de plaats in.</td></tr>
              <?php endif; ?>

              <tr><th>Land</th></tr>
              <?php if($company->country): ?>
                <tr><td data-profile="country"><?php echo e($company->country); ?></td></tr>
              <?php else: ?>
                <tr><td data-profile="country" class="text-muted">Vul hier het land in.</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>

    <?php if(session('notification')): ?>
    <div class="timeline col-xs-12 col-md-6 col-md-offset-3">
      <div class="alert alert-info">
        <div class="container-fluid">
          <div class="alert-icon">
            <i class="material-icons">info_outline</i>
          </div>
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true"><i class="material-icons">clear</i></span>
          </button>
          <b>Info:</b> <?php echo e(session('notification')); ?>

        </div>
      </div>
    </div>
    <?php endif; ?>

    <?php if($company['biography']): ?>
		<div class="card">
      <div class="col-md-12">
        <h2>Biografie</h2>
        <p data-profile="biography"> <?php echo e($company['biography']); ?> </p>
      </div>
		</div>
    <?php endif; ?>

    </div>

    <?php if($role != 0): ?>

    <div class="timeline col-xs-12 col-md-6 col-md-offset-3">

      <div class="new-post">
        <div class="card">
          <div class="col-md-12">
            <form id="newPostForm" method="POST" enctype="multipart/form-data" action="/create-post">
              <?php echo csrf_field(); ?>


              <input type="hidden" name="company_id" value="<?php echo e($company['id']); ?>">

              <div class="form-group">
                <input type="text" name="title" class="form-control" placeholder="Titel *" autocomplete="off">
              </div>

              <div class="form-group">
                <textarea name="message" class="form-control" placeholder="Bericht *" autocomplete="off"></textarea>
              </div>

              <label class="control-label" for="file">Afbeelding</label>
              <input type="file" name="file">

              <div class="form-group">
                <input type="submit" class="btn btn-primary btn-raised pull-right" name="submit" value="Plaatsen">
              </div>

            </form>
          </div>
        </div>
      </div>

      <div class="posts">
            <?php if(count($posts) < 1): ?>
            <div class="card">
              <div class="col-md-12">
    					  <h4>Er zijn nog geen berichten</h4>
              </div>
            </div>
    				<?php else: ?>

              <ul class="nav nav-pills nav-pills-primary posts" role="tablist">
                <li class="active"><a href="#" role="tab" data-id="1" data-toggle="tab">Alle</a></li>
                <li><a href="#schedule" data-id="2" role="tab" data-toggle="tab">Alleen (mede-)beheerders</a></li>
              </ul>

              <div class="the-posts" data-id="1">

                <?php foreach($posts as $post): ?>
                <div class="card">
                  <div class="col-md-12">

                    <?php if($post['user_id'] == \Auth::id() || $role == 2 || $role == 3): ?>
                      <span class="edit-post" data-id="<?php echo e($post->id); ?>" data-toggle="modal" data-target="#editPostModal"><i class="material-icons">edit</i></span>
                      <span class="remove-post" data-id="<?php echo e($post->id); ?>" data-toggle="modal" data-target="#removePostModal"><i class="material-icons">delete_forever</i></span>
                    <?php endif; ?>

                    <h4 class="post-title"><?php echo e($post->title); ?></h4>
                    <p class="post-content"><?php echo e($post->content); ?></p>
                    <?php if($post->image): ?>
                    <div class="post-image">
                      <img src="<?php echo e($post->image); ?>" />
                    </div>
                    <?php endif; ?>
                    <div class="post-footer">
                      <span class="post-author"><b><a href="<?php echo e(url('/user/' . $post->user_id)); ?>"><?php echo e($post->firstname); ?> <?php echo e($post->lastname); ?></a> plaatste dit bericht op: <span style="float:right;"><?php echo e($post->created_at); ?></span></b></span>
                      <?php if($post->created_at != $post->updated_at): ?>
                        <!-- <span class="post-editor"><b><a href="<?php echo e(url('/user/' . $post->edited_by)); ?>"><?php echo e($post->edited_by); ?></a> bewerkte dit bericht op: <span style="float:right;"><?php echo e($post->updated_at); ?></span></b></span> -->
                      <?php endif; ?>
                    </div>

                  </div>
                </div>
                <?php endforeach; ?>
              </div>

              <div class="the-posts" style="display:none;" data-id="2">

                <?php foreach($posts as $post): ?>
                  <?php if($post['role'] == 3): ?>
                    <div class="card">
                      <div class="col-md-12">

                        <?php if($post['user_id'] == \Auth::id() || $role == 2 || $role == 3): ?>
                          <span class="remove-post" data-id="<?php echo e($post->id); ?>" data-toggle="modal" data-target="#removePostModal"><i class="material-icons">delete_forever</i></span>
                        <?php endif; ?>

                        <h4 class="post-title"><?php echo e($post->title); ?></h4>
                        <p class="post-content"><?php echo e($post->content); ?></p>
                        <?php if($post->image): ?>
                        <div class="post-image">
                          <img src="<?php echo e($post->image); ?>" />
                        </div>
                        <?php endif; ?>
                        <div class="post-footer">
                          <span class="post-author"><b><a href="<?php echo e(url('/user/' . $post->user_id)); ?>"><?php echo e($post->firstname); ?> <?php echo e($post->lastname); ?></a> plaatste dit bericht op: <span style="float:right;"><?php echo e($post->created_at); ?></span></b></span>
                          <?php if($post->created_at != $post->updated_at): ?>
                            <span class="post-editor"><b><a href="<?php echo e(url('/user/' . $post->edited_by)); ?>"><?php echo e($post->edited_by); ?></a> bewerkte dit bericht op: <span style="float:right;"><?php echo e($post->updated_at); ?></span></b></span>
                          <?php endif; ?>
                        </div>

                      </div>
                    </div>
                  <?php endif; ?>
                <?php endforeach; ?>
                </div>
              </div>
            <?php endif; ?>
          </div>
        </div>
        <?php endif; ?>
      </div>
    </div>
	</div>

  <div class="modal fade" id="removePostModal" tabindex="-1" role="dialog" aria-labelledby="removePost" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="myModalLabel">Waarschuwing!</h4>
      </div>
      <div class="modal-body">

        <p class="modal-message">
          Weet u zeker dat uw het bericht "<span></span>" wilt verwijderen?
          <br />
          Het is niet mogelijk om dit ongedaan te maken.
        </p>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Annuleren</button>
        <button type="button" class="btn btn-danger" id="removePostButton">Verwijderen</button>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="changeLogoModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="myModalLabel">Logo aanpassen</h4>
      </div>
      <form id="changeLogoForm" method="POST" enctype="multipart/form-data" action="/change-logo">
        <?php echo csrf_field(); ?>

        <input type="hidden" name="company" value="<?php echo e($company['id']); ?>">

        <div class="modal-body">

          <div class="col-sm-6">
           <label class="control-label">Logo</label>
           <input type="file" id="changeLogo" name="changeLogo">
          </div>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Sluiten</button>
          <button type="submit" class="btn btn-info">Opslaan</button>
        </div>
      </form>
    </div>
  </div>
</div>

<div class="modal fade" id="reportCompany" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="myModalLabel"><?php echo e($company->name); ?> rapporteren</h4>
      </div>
      <form id="reportCompanyForm" method="POST" enctype="multipart/form-data" action="/company/report">
        <?php echo csrf_field(); ?>

        <input type="hidden" name="company" value="<?php echo e($company->id); ?>">

        <div class="modal-body">

          <input type="text" name="reason" placeholder="Reden" class="form-control">

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Annuleren</button>
          <button type="submit" class="btn btn-danger">Rapporteren</button>
        </div>
      </form>
    </div>
  </div>
</div>

<div class="modal fade" id="editPostModal" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="myModalLabel">Bericht bewerken</h4>
      </div>
      <form id="editPostForm" method="POST" enctype="multipart/form-data" action="/edit-post">
        <?php echo csrf_field(); ?>

        <input type="hidden" name="company" value="<?php echo e($company->id); ?>">
        <input type="hidden" name="post_id" value="">

        <div class="modal-body">

          <div class="form-group">
            <input type="text" name="title" class="form-control" value="" autocomplete="off">
          </div>

          <div class="form-group">
            <textarea name="message" class="form-control" autocomplete="off"></textarea>
          </div>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Annuleren</button>
          <button type="submit" class="btn btn-success">Opslaan</button>
        </div>
      </form>
    </div>
  </div>
</div>

<button class="btn-profile-save btn btn-primary btn-raised btn-fab btn-round">
  <i class="material-icons">save</i>
</button>

<script>
  var currPage = "company/<?php echo e($company->id); ?>/edit";
</script>

  <?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>