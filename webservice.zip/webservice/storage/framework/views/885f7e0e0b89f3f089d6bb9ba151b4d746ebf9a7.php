<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="container top">
  <div class="notifications">
    <?php if(session('notification')): ?>
    <div class="col-md-12">
      <div class="alert alert-info">
        <div class="container-fluid">
          <div class="alert-icon">
            <i class="material-icons">info_outline</i>
          </div>
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true"><i class="material-icons">clear</i></span>
          </button>
          <b>Info:</b> <span class="message"><?php echo e(session('notification')); ?></span>
        </div>
      </div>
    </div>
    <?php endif; ?>
  </div>
  <div class="row">
    <div class="col-md-7">
      <div class="card">
        <div class="col-md-12">
          <h2>Mijn bedrijven</h2>
          <?php if(count($myCompanies) > 0): ?>
          <ul class="businesses">
            <?php foreach($myCompanies as $company): ?>
            <a href="company/<?php echo e($company->company_id); ?>">
              <li>
                <div class="img-container">
                  <?php if(is_file(public_path().$company->logo)): ?>
                  <img src="<?php echo e(url($company->logo)); ?>" alt="<?php echo e($company->name); ?>">
                  <?php else: ?>
                  <i class="material-icons">business</i>
                  <?php endif; ?>
                </div>
                <div class="info-container">
                  <h3><?php echo e($company->name); ?></h3>
                  <p><?php echo e($company->slogan); ?> <span class="text-right"><?php echo e($company->location); ?>, <?php echo e($company->country); ?></span></p>
                </div>
              </li>
            </a>
            <?php endforeach; ?>
          </ul>
          <?php else: ?>
          <h4 class="no-result">U heeft nog geen bedrijf.</h4>
          <?php endif; ?>
          <p><a href="<?php echo e(url('/create-company')); ?>"><button class="btn btn-raised btn-primary btn-sm pull-right">Bedrijf aanmaken</button></a></p>
        </div>
      </div>
      <div class="card">
        <div class="col-md-12">
          <div class="input-group">
            <input type="text" class="form-control" placeholder="Zoeken naar bedrijven.">
            <span class="input-group-addon" id="searchCompany"><i class="material-icons">search</i></span>
          </div>
          <div id="companySearchResult">
          </div>
          <?php if($nearby['nearby'] == true): ?>
          <h2>In de buurt</h2>
          <?php else: ?>
          <h2>Willekeurige bedrijven</h2>
          <?php if($nearby['user_haslocation'] == false): ?>
          <a href="<?php echo e(url('/user/' . \Auth::id())); ?>">Vul eerst je woonplaats in om te kijken welke bedrijven zich in de buurt bevinden.</a>
          <?php endif; ?>
          <?php endif; ?>
          <ul class="businesses">
            <?php if(count($nearby['companies']) < 1): ?>
            <li>
              <h4 class="no-result">Geen resultaten gevonden...</h4>
            </li>
            <?php else: ?>
            <?php foreach($nearby['companies'] as $company): ?>
            <a href="company/<?php echo e($company->id); ?>">
              <li>
                <div class="img-container">
                  <?php if(is_file(public_path().$company->logo)): ?>
                  <img src="<?php echo e(url($company->logo)); ?>" alt="<?php echo e($company->name); ?>">
                  <?php else: ?>
                  <i class="material-icons">business</i>
                  <?php endif; ?>
                </div>
                <div class="info-container">
                  <h3><?php echo e($company->name); ?></h3>
                  <p><?php echo e($company->slogan); ?> <span class="text-right"><?php echo e($company->location); ?>, <?php echo e($company->country); ?></span></p>
                </div>
              </li>
            </a>
            <?php endforeach; ?>
            <?php endif; ?>
          </ul>
        </div>
      </div>
    </div>
    <div class="col-md-4 col-md-offset-1">
      <div class="card">
        <a href="<?php echo e(url('user/'.\Auth::User()->id)); ?>" class="dashboard-link">
          <?php if($user->profilepicture): ?>
          <img src="<?php echo e($user->profilepicture); ?>" alt="<?php echo e($user->firstname); ?>&nbsp;<?php echo e($user->lastname); ?>" class="img-rounded img-responsive dashboard-profile">
          <?php else: ?>
          <img src="<?php echo e(url('assets/img/avatar.png')); ?>" alt="<?php echo e($user->firstname); ?>&nbsp;<?php echo e($user->lastname); ?>" class="img-rounded img-responsive dashboard-profile">
          <?php endif; ?>
          <p class="dashboard-name"><?php echo e($user->firstname .' '. $user->lastname); ?></p>
        </a>
        <ul class="dashboard-profile-list">
          <?php if($profileProgress < 100): ?>
          <li>
            <i class="material-icons text-info">info</i>
            <p>Vul je profiel verder in. (<?php echo e($profileProgress); ?>%)</p>
            <div class="progress">
              <div class="progress-bar" role="progressbar" aria-valuenow="<?php echo e($profileProgress); ?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo e($profileProgress); ?>%;">
                <span class="sr-only"><?php echo e($profileProgress); ?>% Complete</span>
              </div>
            </div>
            <a href="<?php echo e(url('user/'.\Auth::User()->id)); ?>"><button class="btn btn-primary btn-xs">Bekijken</button></a>
          </li>
          <?php else: ?>
          <li>
            <i class="material-icons text-info">info</i>
            <p>Gefeliciteerd, uw profiel is volledig ingevuld!</p>
          </li>
          <?php endif; ?>
        </ul>
      </div>
    </div>
  </div>
</div>
<?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>